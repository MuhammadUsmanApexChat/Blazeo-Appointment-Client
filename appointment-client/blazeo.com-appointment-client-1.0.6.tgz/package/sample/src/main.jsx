import { applyBlazeoClientConfig } from "appointment-client";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { App } from "./App2.jsx";
import "./style.css";

/** Apply file defaults (`blazeoClientDefaults.ts`) before React mounts. */
applyBlazeoClientConfig();

const rootEl = document.getElementById("app");
if (!rootEl) {
  throw new Error("Missing #app element");
}

createRoot(rootEl).render(
  <StrictMode>
    <App />
  </StrictMode>
);
