import {
  createContext,
  useContext,
  useEffect,
  useLayoutEffect,
  useMemo,
  useState,
} from "react";
import { blazeoClientConfig, initializeAppointmentClient } from "appointment-client";
import { configure as configureCalendarClient } from "@blazeo.com/calendar-client";

const STORAGE_BASE = "appointment-client-sample:blazeoBaseUrl";
const STORAGE_CONSUMER = "appointment-client-sample:blazeoConsumer";

function readStored(key) {
  try {
    return localStorage.getItem(key) ?? "";
  } catch {
    return "";
  }
}

function writeStored(key, value) {
  try {
    if (value) localStorage.setItem(key, value);
    else localStorage.removeItem(key);
  } catch {
    /* ignore */
  }
}

function normalizeBase(u) {
  const t = (u ?? "").trim();
  if (!t) return "";
  return t.replace(/\/+$/, "");
}

/** Merge UI fields with packaged defaults (`blazeoClientDefaults`) when inputs are empty. */
export function mergeBlazeoUiWithFile(uiBaseUrl, uiConsumer) {
  const fileBase = normalizeBase(blazeoClientConfig.baseUrl ?? "");
  const fileConsumer = (blazeoClientConfig.consumer ?? "").trim();
  const baseUrl = normalizeBase(uiBaseUrl) || fileBase || undefined;
  const consumer = (uiConsumer ?? "").trim() || fileConsumer || undefined;
  return { baseUrl, consumer };
}

/**
 * Re-apply global Blazeo `configure` from the effective connection card state.
 * Call at the start of any handler that uses `CalendarModel` / `EventModel` HTTP so
 * `getParticipantOpeningHours` (instance env) and static helpers always see the same
 * `baseUrl`.
 */
export function configureBlazeoFromEffective(effective) {
  const baseUrl = normalizeBase(effective?.baseUrl ?? "");
  if (!baseUrl) return;
  const consumer = (effective?.consumer ?? "").trim() || undefined;
  // Configure appointment-client (which configures its internal calendar-client instance)
  initializeAppointmentClient({ baseUrl, ...(consumer ? { consumer } : {}) });
  // Also configure the calendar-client instance that the sample (and Vite alias) may resolve.
  configureCalendarClient({ baseUrl, ...(consumer ? { consumer } : {}) });
}

const BlazeoConnectionContext = createContext(null);

export function BlazeoConnectionProvider({ children }) {
  const [baseUrlInput, setBaseUrlInput] = useState(() => readStored(STORAGE_BASE));
  const [consumerInput, setConsumerInput] = useState(() => readStored(STORAGE_CONSUMER));

  const effective = useMemo(
    () => mergeBlazeoUiWithFile(baseUrlInput, consumerInput),
    [baseUrlInput, consumerInput]
  );

  useEffect(() => {
    writeStored(STORAGE_BASE, baseUrlInput.trim());
  }, [baseUrlInput]);

  useEffect(() => {
    writeStored(STORAGE_CONSUMER, consumerInput.trim());
  }, [consumerInput]);

  /**
   * Sync global Blazeo `configure` before paint so `CalendarModel.get` /
   * `EventModel.*` static calls never see an empty `getConfig()` after the user
   * has set Base URL (including values restored from localStorage on first paint).
   */
  useLayoutEffect(() => {
    const { baseUrl, consumer } = mergeBlazeoUiWithFile(baseUrlInput, consumerInput);
    if (!baseUrl) return;
    initializeAppointmentClient({ baseUrl, ...(consumer ? { consumer } : {}) });
    configureCalendarClient({ baseUrl, ...(consumer ? { consumer } : {}) });
  }, [baseUrlInput, consumerInput]);

  const value = useMemo(
    () => ({
      baseUrlInput,
      consumerInput,
      setBaseUrlInput,
      setConsumerInput,
      effective,
    }),
    [baseUrlInput, consumerInput, effective]
  );

  return (
    <BlazeoConnectionContext.Provider value={value}>
      {children}
    </BlazeoConnectionContext.Provider>
  );
}

export function useBlazeoConnection() {
  const ctx = useContext(BlazeoConnectionContext);
  if (ctx == null) {
    throw new Error("useBlazeoConnection must be used within BlazeoConnectionProvider");
  }
  return ctx;
}
