import { CalendarModel } from "@blazeo.com/calendar-client";
import { getSnapshot } from "mobx-state-tree";
import {
  unwrapCalendarGetData,
  pickOpeningHoursArrayFromCalendarPayload,
  normalizeParticipantOpeningHoursResponse,
} from "./fetchCalendarWithOpeningHours.js";
import { buildUnifiedCalendarView, type UnifiedCalendarView } from "./buildUnifiedCalendarView.js";

/**
 * Normalizes the REST envelope from `calendar.getParticipantOpeningHours()`
 * (`GET /Calendar/Participant/OpeningHours/Get`) into a plain row array.
 */
export function normalizeOpeningHours(res: any): any[] {
  const { list } = normalizeParticipantOpeningHoursResponse(res);
  return Array.isArray(list) ? list : [];
}

function normalizeAllParticipantOpeningHoursResult(raw: any): any[] {
  if (Array.isArray(raw)) return raw;
  const { list } = normalizeParticipantOpeningHoursResponse(raw);
  return Array.isArray(list) ? list : [];
}

/** Prefer union of `/Participant/All` and `/Participant/Get` so members reconcile when either list is incomplete. */
function mergeParticipantSnapshots(
  a: any[] | null | undefined,
  b: any[] | null | undefined
): any[] {
  const byKey = new Map<string, any>();
  const ingest = (p: any) => {
    if (p == null) return;
    const participantId = String(
      p.participantId ?? p.ParticipantId ?? p.participant_id ?? ""
    ).trim().toLowerCase();
    const calPartId = String(
      p.calendarParticipantId ?? p.CalendarParticipantId ?? p.calendarparticipant_id ?? ""
    ).trim()
      .toLowerCase();
    const key = participantId || calPartId;
    if (!key) return;
    if (!byKey.has(key)) byKey.set(key, p);
  };
  if (Array.isArray(a)) a.forEach(ingest);
  if (Array.isArray(b)) b.forEach(ingest);
  return [...byKey.values()];
}

/** Coerce MST / envelope / nested `data` shapes into a plain array for participants and GetInfo lists. */
function unwrapModelList(raw: any): any[] {
  if (raw == null) return [];
  if (Array.isArray(raw)) return raw;
  if (typeof raw === "string") {
    try {
      return unwrapModelList(JSON.parse(raw));
    } catch {
      return [];
    }
  }
  if (typeof raw !== "object") return [];
  const topArr = (raw as any).items ?? (raw as any).Items;
  if (Array.isArray(topArr)) return topArr;
  const d = raw.data ?? raw.Data;
  if (Array.isArray(d)) return d;
  if (d != null && typeof d === "object") {
    const inner = (d as any).data ?? (d as any).Data ?? (d as any).items ?? (d as any).Items;
    if (Array.isArray(inner)) return inner;
  }
  return [];
}

/**
 * Calendar + legacy opening hours + full detail bundle (`fetchCalendarDetails`), **or**
 * only the **single unified object** via {@link fetchCalendarBundle}.
 *
 * **Flow**
 * 1. **Calendar** — parallel `CalendarModel.get` + `getRaw` (both `GET /Calendar/Get`: model + raw envelope).
 * 2. **Legacy `openingHours`** — embed from raw, else `getParticipantOpeningHours` (narrow endpoint).
 * 3. **`calendarView` (one object)** — in parallel after calendar is known:
 *    - `GET /Calendar/Participant/All` and optional `/Participant/Get` merge when both return rows.
 *    - `GET /Calendar/Participants/GetInfo`
 *    - `GET /Calendar/Participant/OpeningHours/All/Get` when options enable it (`preferAllParticipantOpeningHours`)
 *    Then `calendarView` = calendar snapshot fields + **`members`** (with **`participantInfo`**) + **`openingHours`**
 *    (`openingHours[].member` → `members[].id`).
 *
 * Server still performs multiple HTTP calls; on the client, **`calendarView`** is returned as **one object**.
 */
export async function fetchCalendarDetails(
  calendarId: string,
  options: {
    includeParticipantsInfo?: boolean;
    includeUnifiedCalendarView?: boolean;
    /** Prefer all-participant opening hours for **`calendarView`** when the API returns rows (default `true`). */
    preferAllParticipantOpeningHours?: boolean;
  } = {}
) {
  const {
    includeParticipantsInfo = false,
    includeUnifiedCalendarView = true,
    preferAllParticipantOpeningHours = true,
  } = options;

  const fetchParticipantsInfo = includeParticipantsInfo || includeUnifiedCalendarView;
  const fetchAllHours = includeUnifiedCalendarView && preferAllParticipantOpeningHours;

  // Calendar: `GET /Calendar/Get` is used twice (model + raw for embed) — run in parallel.
  const [cal, rawRes]: [any, any] = await Promise.all([
    CalendarModel.get(calendarId),
    (CalendarModel as any).getRaw(calendarId),
  ]);
  if (cal == null) {
    return {
      calendar: null,
      cal: null,
      calendarView: null as UnifiedCalendarView | null,
      openingHours: [] as any[],
      participants: [] as any[],
      participantsInfo: null as any,
      allParticipantOpeningHours: null as any[] | null,
      embeddedFromGet: [] as any[],
      fromCalendarGet: false,
      fromParticipantApi: false,
      participantOpeningHoursResponse: null as any,
      rawGet: rawRes,
      meta: { ok: false as const, reason: "calendar_not_found" },
    };
  }

  const payload = unwrapCalendarGetData(rawRes);
  const embedded = pickOpeningHoursArrayFromCalendarPayload(payload) ?? [];
  let participantOpeningHoursResponse: any = null;
  let resolved: any[] | null = embedded.length > 0 ? embedded : null;

  if ((resolved == null || resolved.length === 0) && cal != null) {
    participantOpeningHoursResponse = await cal.getParticipantOpeningHours({ calendarId });
    const { list } = normalizeParticipantOpeningHoursResponse(participantOpeningHoursResponse);
    if (list != null && list.length > 0) resolved = list;
  }

  const openingHours = Array.isArray(resolved) ? resolved : [];

  // 2) Participants + participant info + all participant opening hours (parallel)
  const getCalPart = (CalendarModel as any).getCalendarParticipant;
  const participantsViaGetPromise =
    includeUnifiedCalendarView && typeof getCalPart === "function"
      ? getCalPart.call(CalendarModel, calendarId)
      : Promise.resolve(null);

  const [participants, participantsViaGet, participantsInfo, allHoursRaw] = await Promise.all([
    CalendarModel.getParticipants(calendarId),
    participantsViaGetPromise,
    fetchParticipantsInfo ? CalendarModel.getParticipantsInfo(calendarId) : Promise.resolve(null),
    fetchAllHours ? (CalendarModel as any).getAllParticipantOpeningHours(calendarId) : Promise.resolve(null),
  ]);

  const snap = getSnapshot(cal);
  const calendar = { ...(snap as any), openingHours };

  const participantList = mergeParticipantSnapshots(
    unwrapModelList(participants),
    unwrapModelList(participantsViaGet)
  );
  const infoUnwrapped = fetchParticipantsInfo ? unwrapModelList(participantsInfo) : [];
  const infoListForView = infoUnwrapped.length > 0 ? infoUnwrapped : null;

  const allParticipantOpeningHours = fetchAllHours ? normalizeAllParticipantOpeningHoursResult(allHoursRaw) : null;

  const openingHoursForUnifiedView =
    includeUnifiedCalendarView &&
    preferAllParticipantOpeningHours &&
    allParticipantOpeningHours != null &&
    allParticipantOpeningHours.length > 0
      ? allParticipantOpeningHours
      : openingHours;

  const calendarView = includeUnifiedCalendarView
    ? buildUnifiedCalendarView(snap as any, openingHoursForUnifiedView, participantList, infoListForView)
    : null;

  const unifiedUsedAllEndpoint =
    includeUnifiedCalendarView &&
    preferAllParticipantOpeningHours &&
    allParticipantOpeningHours != null &&
    allParticipantOpeningHours.length > 0;

  return {
    calendar,
    cal,
    calendarView,
    openingHours,
    participants: participantList,
    participantsInfo,
    allParticipantOpeningHours,
    embeddedFromGet: embedded,
    fromCalendarGet: embedded.length > 0,
    fromParticipantApi: embedded.length === 0 && openingHours.length > 0 && participantOpeningHoursResponse != null,
    participantOpeningHoursResponse,
    meta: {
      ok: true as const,
      /** `calendarView.openingHours` came from OpeningHours/All/Get */
      calendarViewUsedAllParticipantOpeningHours: unifiedUsedAllEndpoint,
      ...(calendarView != null
        ? {
            calendarViewMemberCount: calendarView.members.length,
            calendarViewOpeningHourCount: calendarView.openingHours.length,
          }
        : {}),
    },
  };
}

/**
 * Single return value only: unified calendar **`calendarView`** —
 * snapshot fields plus **`members`** (with **`participantInfo`**) plus **`openingHours`**
 * (prefers all-participant opening hours when available). Same shape as `fetchCalendarDetails().calendarView`.
 * Returns **`null`** if the calendar cannot be loaded (`CalendarModel.get`).
 */
export async function fetchCalendarBundle(calendarId: string): Promise<UnifiedCalendarView | null> {
  const d = await fetchCalendarDetails(calendarId, {
    includeUnifiedCalendarView: true,
    includeParticipantsInfo: true,
    preferAllParticipantOpeningHours: true,
  });
  if (!d.meta.ok) return null;
  return d.calendarView;
}
