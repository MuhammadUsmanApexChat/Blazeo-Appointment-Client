import { CalendarModel } from "@blazeo.com/calendar-client";

/**
 * Fetches participants for a calendar.
 */
export async function getParticipants(calendarId: string) {
  const participants = await CalendarModel.getParticipants(calendarId);
  return Array.isArray(participants) ? participants : [];
}
