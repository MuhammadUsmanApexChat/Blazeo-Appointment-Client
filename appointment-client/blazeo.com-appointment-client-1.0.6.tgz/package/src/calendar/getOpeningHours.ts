import { fetchCalendarWithOpeningHours } from "./fetchCalendarWithOpeningHours.js";

/**
 * Fetches opening hours for a calendar.
 * Automatically handles embedded calendar-level hours and participant-level fallbacks.
 */
export async function getOpeningHours(calendarId: string) {
  const result = await fetchCalendarWithOpeningHours(calendarId);
  return result.openingHours;
}
