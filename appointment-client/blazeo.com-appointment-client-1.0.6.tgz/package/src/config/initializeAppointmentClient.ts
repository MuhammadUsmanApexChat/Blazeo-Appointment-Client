import { configure, getConfig } from "@blazeo.com/calendar-client";

export interface AppointmentClientConfig {
  baseUrl: string;
  consumer?: string;
  fetch?: typeof fetch;
}

let isConfigured = false;

export function initializeAppointmentClient(config: AppointmentClientConfig) {
  configure(config);
  isConfigured = true;
}

export function isAppointmentClientConfigured() {
  return isConfigured || getConfig() !== null;
}
