import { configure } from "@blazeo.com/calendar-client";
import { blazeoClientConfig } from "./blazeoClientDefaults.js";

/** Push {@link blazeoClientConfig} into `@blazeo.com/calendar-client` (global store). Call explicitly if you use file defaults; otherwise use {@link initializeAppointmentClient}. */
export function applyBlazeoClientConfig() {
  const baseUrl = blazeoClientConfig.baseUrl?.trim().replace(/\/+$/, "");
  if (!baseUrl) return;
  const consumer = blazeoClientConfig.consumer?.trim();
  configure({
    baseUrl,
    ...(consumer ? { consumer } : {}),
  });
}
